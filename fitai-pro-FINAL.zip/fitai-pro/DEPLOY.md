# 🚀 FitAI Pro — Deploy in 10 Minutes

## Step 1 — Prerequisites
Install on your PC:
- **Node.js 18+**: https://nodejs.org (LTS)
- **Git**: https://git-scm.com

## Step 2 — Setup
```bash
# Terminal mein project folder mein jao
cd fitai-pro

# Dependencies install karo
npm install

# .env file banao
cp .env.example .env
```

`.env` file mein fill karo:
```
VITE_ANTHROPIC_API_KEY=sk-ant-xxxxx
```
API key: https://console.anthropic.com → API Keys → Create Key

## Step 3 — Test Locally
```bash
npm run dev
# Browser: http://localhost:5173
```

## Step 4 — Deploy to Vercel

### GitHub se (Recommended):
```bash
git init
git add .
git commit -m "FitAI Pro"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/fitai-pro.git
git push -u origin main
```

Then:
1. vercel.com → Login with GitHub
2. New Project → Select your repo
3. Add Environment Variable: `VITE_ANTHROPIC_API_KEY` = your key
4. Deploy → Done! 🎉

### OR Vercel CLI:
```bash
npx vercel
# Follow prompts
```

## Payment Flow
User → Subscribe → PhonePe QR scan → Pay exact amount →
WhatsApp screenshot to +919399470011 → You verify → Activate

## File Structure
```
fitai-pro/
├── public/phonepe-qr.png     ← Your QR ✓
├── src/
│   ├── pages/
│   │   ├── Auth.jsx          ← Login/Signup ✓
│   │   ├── Onboarding.jsx    ← 3-step profile
│   │   ├── Dashboard.jsx     ← Home
│   │   ├── WorkoutDietPosingProgress.jsx
│   │   ├── Coach.jsx         ← AI Chat
│   │   └── Subscription.jsx  ← Payment + QR ✓
│   ├── components/
│   │   ├── Sidebar.jsx       ← With logout ✓
│   │   └── MobileHeader.jsx
│   └── lib/
│       ├── ai.js             ← Claude API
│       └── store.js          ← localStorage
├── .env.example
├── vercel.json
└── package.json
```

## Costs
- Vercel: FREE
- Anthropic API: ~₹50-200/month
- Domain: ₹500/year (optional)
