export default function Dashboard({ state, navigate }) {
  const { user, plan, streak = 1, activePlan } = state
  if (!plan) return null

  const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']
  const today = days[new Date().getDay()]
  const todayPlan = plan.weeklySchedule?.find(d => d.day === today) || plan.weeklySchedule?.[0]

  const stats = [
    { icon: '🔥', label: 'Daily Calories', value: `${plan.calories} kcal`, sub: 'Target per day' },
    { icon: '🥩', label: 'Protein Goal', value: `${plan.protein}g`, sub: 'Per day' },
    { icon: '💪', label: 'Training Days', value: user.days, sub: 'Per week' },
    { icon: '⚖️', label: 'Weight', value: `${user.weight} kg`, sub: 'Starting' },
  ]

  return (
    <div style={{ animation: 'fadeUp 0.4s ease both' }}>
      {/* Greeting */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 24, flexWrap: 'wrap', gap: 16 }}>
        <div>
          <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 4 }}>Welcome back 💪</div>
          <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 'clamp(22px,3vw,32px)', fontWeight: 800, letterSpacing: -1 }}>{user.name} 👋</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'var(--accent-dim)', border: '1px solid var(--accent-border)', padding: '10px 18px', borderRadius: 100, fontFamily: 'Syne,sans-serif', fontSize: 16, fontWeight: 800, color: 'var(--accent)' }}>
          🔥 {streak} Day Streak
        </div>
      </div>

      {/* Goal banner */}
      <div style={{ background: 'var(--accent-dim)', border: '1px solid var(--accent-border)', borderRadius: 12, padding: '13px 18px', display: 'flex', alignItems: 'center', gap: 12, fontSize: 13, marginBottom: 24 }}>
        <span style={{ fontSize: 20 }}>🎯</span>
        <span><strong>Goal:</strong> {user.goal} &nbsp;|&nbsp; <strong>Level:</strong> {user.level} &nbsp;|&nbsp; <strong>BMI:</strong> {(user.weight / ((user.height / 100) ** 2)).toFixed(1)}</span>
      </div>

      {/* Stats */}
      <div className="grid-4" style={{ marginBottom: 24 }}>
        {stats.map((s, i) => (
          <div key={i} className="card" style={{ position: 'relative', overflow: 'hidden', transition: 'all 0.3s ease', cursor: 'default', animation: `fadeUp 0.4s ${i * 0.08}s ease both` }}
            onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-4px)'}
            onMouseLeave={e => e.currentTarget.style.transform = 'translateY(0)'}>
            <div style={{ position: 'absolute', top: -20, right: -20, width: 80, height: 80, background: 'radial-gradient(circle, rgba(200,255,0,0.06), transparent)', borderRadius: '50%' }} />
            <div style={{ fontSize: 22, marginBottom: 12 }}>{s.icon}</div>
            <div style={{ fontSize: 10, letterSpacing: 1.5, textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 4 }}>{s.label}</div>
            <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 'clamp(18px,2.5vw,26px)', fontWeight: 800, letterSpacing: -1, color: 'var(--accent)' }}>{s.value}</div>
            <div style={{ fontSize: 11, color: 'var(--dim)', marginTop: 3 }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Today's workout */}
      <div className="card" style={{ marginBottom: 24, position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', right: -30, top: -30, width: 150, height: 150, background: 'radial-gradient(circle, rgba(200,255,0,0.04), transparent)', borderRadius: '50%' }} />
        <div style={{ fontSize: 10, letterSpacing: 2, color: 'var(--accent)', textTransform: 'uppercase', marginBottom: 8 }}>⚡ Today's Workout</div>
        <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 'clamp(20px,2.5vw,26px)', fontWeight: 800, letterSpacing: -0.5, marginBottom: 6 }}>
          {todayPlan?.emoji} {todayPlan?.focus}
        </div>
        <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 20 }}>
          {todayPlan?.isRest ? 'Rest & Recovery — aaram karo aaj 🌿' : `${todayPlan?.exercises?.length} exercises — push karo aaj!`}
        </div>
        {!todayPlan?.isRest && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 20 }}>
            {todayPlan?.exercises?.slice(0, 4).map((ex, i) => (
              <div key={i} style={{ background: 'var(--card2)', border: '1px solid var(--border2)', padding: '5px 12px', borderRadius: 100, fontSize: 12, color: 'var(--muted)' }}>
                {ex.split(' ').slice(0, 2).join(' ')}
              </div>
            ))}
          </div>
        )}
        <button className="btn-accent" onClick={() => navigate('workout')}>
          {todayPlan?.isRest ? '😴 Rest Day' : 'Start Workout 💪'}
        </button>
      </div>

      {/* Weekly grid */}
      <div className="card" style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 10, letterSpacing: 2.5, textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 14 }}>This Week</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 8 }}>
          {plan.weeklySchedule?.map((d, i) => {
            const isToday = d.day === today
            return (
              <div key={i} style={{ background: isToday ? 'var(--accent-dim)' : 'var(--card2)', border: `1px solid ${isToday ? 'var(--accent)' : 'var(--border)'}`, borderRadius: 12, padding: '10px 4px', textAlign: 'center', opacity: d.isRest ? 0.45 : 1, transition: 'all 0.2s ease', cursor: 'pointer' }}
                onClick={() => navigate('workout')}>
                <div style={{ fontSize: 8, letterSpacing: 1, textTransform: 'uppercase', color: isToday ? 'var(--accent)' : 'var(--muted)', marginBottom: 6 }}>{d.day.slice(0, 3)}</div>
                <div style={{ fontSize: 18, marginBottom: 4 }}>{d.emoji}</div>
                <div style={{ fontSize: 8, color: isToday ? 'var(--accent)' : 'var(--dim)', fontWeight: isToday ? 600 : 400 }}>{d.isRest ? 'Rest' : d.focus.split(' ')[0]}</div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Upgrade card — show only on free plan */}
      {activePlan === 'free' && (
        <div onClick={() => navigate('subscription')} style={{ background: 'linear-gradient(135deg, rgba(200,255,0,0.08), rgba(0,212,255,0.04))', border: '1px solid rgba(200,255,0,0.2)', borderRadius: 18, padding: '24px', display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap', cursor: 'pointer', transition: 'all 0.3s ease' }}
          onMouseEnter={e => e.currentTarget.style.borderColor = 'rgba(200,255,0,0.4)'}
          onMouseLeave={e => e.currentTarget.style.borderColor = 'rgba(200,255,0,0.2)'}>
          <div style={{ fontSize: 36 }}>👑</div>
          <div style={{ flex: 1, minWidth: 140 }}>
            <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 16, fontWeight: 800, marginBottom: 4 }}>Pro Plan Unlock Karo</div>
            <div style={{ fontSize: 12, color: 'var(--muted)' }}>Voice coach, posing guide, unlimited AI — Rs.299/month</div>
          </div>
          <div style={{ background: 'var(--accent)', color: '#000', padding: '10px 20px', borderRadius: 12, fontFamily: 'Syne,sans-serif', fontSize: 12, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase', whiteSpace: 'nowrap' }}>
            Upgrade →
          </div>
        </div>
      )}
    </div>
  )
}
