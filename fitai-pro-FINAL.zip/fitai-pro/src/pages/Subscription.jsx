import { useState } from 'react'

const PLANS = {
  monthly: { pro: 299, elite: 699 },
  yearly: { pro: 1999, elite: 4499 },
}

const FEATURES = {
  pro: ['Unlimited AI Coach chat', 'Full workout mode + voice coach', 'Complete posing guide', 'Indian diet planner', 'Progress tracking + badges', 'Streak system'],
  elite: ['Everything in Pro', 'AI Pose Analyzer (score/10)', 'AR skeleton overlay', 'Monthly PDF report', 'Priority 24/7 support', 'Nutrition consultation'],
}

const FAQS = [
  { q: 'Payment ke baad plan kab activate hoga?', a: 'Screenshot bhejo UPI payment ka — 15 minute mein activate ho jaayega. WhatsApp ya email pe confirm aayega.' },
  { q: 'Cancel kaise karein?', a: 'Anytime cancel kar sakte ho — koi penalty nahi. Support pe contact karo.' },
  { q: 'Kya 7-day trial hai?', a: 'Haan! Pehle 7 din try karo — satisfied nahi to full refund.' },
  { q: 'Kya dono PhonePe aur UPI work karta hai?', a: 'Haan — QR code scan karo kisi bhi UPI app se: GPay, Paytm, PhonePe, BHIM sab chalega.' },
]

export default function Subscription({ state, update, navigate }) {
  const [billing, setBilling] = useState('monthly')
  const [modal, setModal] = useState(null) // null | 'pro' | 'elite' | 'success'
  const [successPlan, setSuccessPlan] = useState('')
  const { activePlan = 'free' } = state

  const openModal = (plan) => setModal(plan)
  const closeModal = () => setModal(null)

  const confirmPayment = (plan) => {
    const label = plan === 'pro' ? 'Pro ⚡' : 'Elite 💎'
    setSuccessPlan(label)
    setModal('success')
    update({ activePlan: plan })
    // Confetti
    shootConfetti()
  }

  const shootConfetti = () => {
    const colors = ['#C8FF00', '#FF6B35', '#00D4FF', '#ffffff', '#ffcc00']
    for (let i = 0; i < 60; i++) {
      setTimeout(() => {
        const c = document.createElement('div')
        const size = 6 + Math.random() * 10
        c.style.cssText = `position:fixed;left:${Math.random() * 100}vw;top:-10px;width:${size}px;height:${size}px;background:${colors[Math.floor(Math.random() * colors.length)]};border-radius:${Math.random() > 0.5 ? '50%' : '3px'};pointer-events:none;z-index:9999;animation:confettiFall ${1.5 + Math.random() * 2}s linear ${Math.random() * 0.5}s forwards`
        document.body.appendChild(c)
        setTimeout(() => c.remove(), 3000)
      }, i * 25)
    }
  }

  const price = (plan) => PLANS[billing][plan]

  return (
    <div style={{ animation: 'fadeUp 0.4s ease both' }}>
      {/* Hero */}
      <div style={{ background: 'linear-gradient(135deg, rgba(200,255,0,0.08), rgba(0,212,255,0.04))', border: '1px solid rgba(200,255,0,0.15)', borderRadius: 20, padding: '32px', marginBottom: 32, textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: -40, right: -40, width: 200, height: 200, background: 'radial-gradient(circle, rgba(200,255,0,0.06), transparent)', borderRadius: '50%', pointerEvents: 'none' }} />
        <div style={{ fontSize: 10, letterSpacing: 3, textTransform: 'uppercase', color: 'var(--accent)', marginBottom: 12 }}>Choose Your Plan</div>
        <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 'clamp(22px,4vw,38px)', fontWeight: 800, letterSpacing: -2, marginBottom: 8, lineHeight: 1.1 }}>
          Rs.10,000/month ka trainer.<br /><span style={{ color: 'var(--accent)' }}>Rs.299 mein.</span>
        </div>
        <div style={{ fontSize: 13, color: 'var(--muted)' }}>Cancel anytime · 7-day money back · UPI / PhonePe accepted</div>
      </div>

      {/* Active plan banner */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, background: 'var(--card2)', border: '1px solid var(--border2)', borderRadius: 12, padding: '13px 18px', marginBottom: 28 }}>
        <span style={{ fontSize: 22 }}>{activePlan === 'elite' ? '💎' : activePlan === 'pro' ? '⚡' : '🆓'}</span>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 700, fontSize: 14 }}>
            {activePlan === 'elite' ? 'Elite Plan Active' : activePlan === 'pro' ? 'Pro Plan Active' : 'Free Plan Active'}
          </div>
          <div style={{ fontSize: 12, color: 'var(--muted)' }}>
            {activePlan === 'free' ? 'Upgrade karo — unlock all features' : 'Sab features unlock hain 🎉'}
          </div>
        </div>
        <div style={{ background: activePlan === 'elite' ? 'var(--orange)' : activePlan === 'pro' ? 'var(--accent)' : 'var(--card)', color: activePlan === 'free' ? 'var(--muted)' : '#000', fontSize: 10, fontWeight: 700, padding: '4px 12px', borderRadius: 100, letterSpacing: 1 }}>
          {activePlan.toUpperCase()}
        </div>
      </div>

      {/* Billing toggle */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14, marginBottom: 32 }}>
        <span onClick={() => setBilling('monthly')} style={{ fontSize: 13, color: billing === 'monthly' ? 'var(--accent)' : 'var(--muted)', cursor: 'pointer', fontWeight: billing === 'monthly' ? 600 : 400, transition: 'all 0.2s ease' }}>Monthly</span>
        <div onClick={() => setBilling(b => b === 'monthly' ? 'yearly' : 'monthly')} style={{ width: 48, height: 26, background: 'var(--accent)', borderRadius: 100, cursor: 'pointer', position: 'relative', flexShrink: 0 }}>
          <div style={{ width: 18, height: 18, background: '#000', borderRadius: '50%', position: 'absolute', top: 4, left: 4, transition: 'transform 0.3s ease', transform: billing === 'yearly' ? 'translateX(22px)' : 'translateX(0)' }} />
        </div>
        <span onClick={() => setBilling('yearly')} style={{ fontSize: 13, color: billing === 'yearly' ? 'var(--accent)' : 'var(--muted)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8 }}>
          Yearly
          <span style={{ background: 'var(--orange)', color: '#fff', fontSize: 9, fontWeight: 700, padding: '2px 8px', borderRadius: 100 }}>SAVE 45%</span>
        </span>
      </div>

      {/* Plan cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 32 }} className="plan-grid">
        {/* FREE */}
        <PlanCard
          tag="🆓 Free Forever"
          price="₹0"
          period="No credit card"
          features={['Basic workout plan', 'Basic diet tracking', '5 AI chats/day']}
          missing={['Posing module', 'Voice coach', 'Workout mode']}
          btnLabel={activePlan === 'free' ? 'Current Plan' : 'Downgrade'}
          btnStyle={{ background: 'transparent', color: 'var(--muted)', border: '1px solid var(--border2)' }}
          onBtn={() => alert('Free plan pe already ho ya downgrade karo from settings')}
          accentColor="var(--muted)"
        />

        {/* PRO */}
        <PlanCard
          featured
          tag="⭐ Most Popular"
          planLabel="Pro Plan"
          price={`₹${price('pro').toLocaleString('en-IN')}`}
          period={billing === 'yearly' ? 'per year (₹167/mo)' : 'per month'}
          features={FEATURES.pro}
          btnLabel={activePlan === 'pro' ? '✓ Active' : '7-Day Free Trial →'}
          btnStyle={{ background: '#000', color: 'var(--accent)', border: 'none' }}
          onBtn={() => activePlan !== 'pro' && openModal('pro')}
          note="Cancel anytime · No lock-in"
          accentColor="var(--accent)"
          isActive={activePlan === 'pro'}
        />

        {/* ELITE */}
        <PlanCard
          tag="💎 Elite"
          planLabel="Elite Plan"
          price={`₹${price('elite').toLocaleString('en-IN')}`}
          period={billing === 'yearly' ? 'per year (₹375/mo)' : 'per month'}
          features={FEATURES.elite}
          btnLabel={activePlan === 'elite' ? '✓ Active' : 'Go Elite →'}
          btnStyle={{ background: 'transparent', color: 'var(--orange)', border: '1px solid var(--orange)' }}
          onBtn={() => activePlan !== 'elite' && openModal('elite')}
          note="7-day money back guarantee"
          accentColor="var(--orange)"
          eliteBadge
          isActive={activePlan === 'elite'}
        />
      </div>

      {/* FAQ */}
      <div className="card" style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 10, letterSpacing: 2, textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 16 }}>Aksar Pooche Jane Wale Sawaal</div>
        {FAQS.map((f, i) => <FaqItem key={i} q={f.q} a={f.a} />)}
      </div>

      {/* Trust */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, justifyContent: 'center', paddingBottom: 16 }}>
        {['🔒 SSL Secured', '↩️ Cancel Anytime', '📱 UPI / PhonePe', '🛡️ 7-Day Money Back', '🇮🇳 Made in India'].map((t, i) => (
          <div key={i} style={{ background: 'var(--card)', border: '1px solid var(--border)', padding: '8px 14px', borderRadius: 100, fontSize: 11, color: 'var(--muted)' }}>{t}</div>
        ))}
      </div>

      {/* Payment Modal */}
      {modal && modal !== 'success' && (
        <PaymentModal
          plan={modal}
          billing={billing}
          price={price(modal)}
          onClose={closeModal}
          onConfirm={() => confirmPayment(modal)}
        />
      )}

      {/* Success Modal */}
      {modal === 'success' && (
        <SuccessModal
          plan={successPlan}
          onClose={() => { setModal(null); navigate('dashboard') }}
        />
      )}
    </div>
  )
}

function PlanCard({ tag, planLabel, price, period, features, missing = [], btnLabel, btnStyle, onBtn, note, accentColor, featured, eliteBadge, isActive }) {
  return (
    <div style={{
      background: featured ? 'var(--accent)' : 'var(--card)',
      border: `2px solid ${featured ? 'var(--accent)' : 'var(--border)'}`,
      borderRadius: 18,
      padding: featured ? '36px 22px 28px' : '28px 20px',
      position: 'relative',
      transform: featured ? 'scale(1.03)' : 'none',
      boxShadow: featured ? '0 16px 50px rgba(200,255,0,0.2)' : 'none',
      transition: 'all 0.3s ease',
      zIndex: featured ? 2 : 1,
    }}>
      {featured && (
        <div style={{ position: 'absolute', top: -13, left: '50%', transform: 'translateX(-50%)', background: '#000', color: 'var(--accent)', fontSize: 9, fontWeight: 700, letterSpacing: 2, padding: '4px 14px', borderRadius: 100, border: '1px solid rgba(200,255,0,0.4)', whiteSpace: 'nowrap' }}>
          ⭐ MOST POPULAR
        </div>
      )}
      {eliteBadge && (
        <div style={{ position: 'absolute', top: -13, right: 16, background: 'var(--orange)', color: '#fff', fontSize: 9, fontWeight: 700, letterSpacing: 1, padding: '4px 10px', borderRadius: 100 }}>
          💎 ELITE
        </div>
      )}
      <div style={{ fontSize: 9, letterSpacing: 2, textTransform: 'uppercase', color: featured ? 'rgba(0,0,0,0.5)' : 'var(--muted)', marginBottom: 10 }}>{planLabel || tag}</div>
      <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 36, fontWeight: 800, letterSpacing: -2, lineHeight: 1, color: featured ? '#000' : 'var(--text)', marginBottom: 4 }}>{price}</div>
      <div style={{ fontSize: 11, color: featured ? 'rgba(0,0,0,0.5)' : 'var(--muted)', marginBottom: 20 }}>{period}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 20, fontSize: 12 }}>
        {features.map((f, i) => (
          <div key={i} style={{ display: 'flex', gap: 8, color: featured ? 'rgba(0,0,0,0.8)' : 'var(--muted)' }}>
            <span style={{ color: featured ? '#000' : accentColor, fontWeight: 700, flexShrink: 0 }}>✓</span>{f}
          </div>
        ))}
        {missing.map((f, i) => (
          <div key={i} style={{ display: 'flex', gap: 8, color: featured ? 'rgba(0,0,0,0.3)' : 'var(--dim)' }}>
            <span style={{ flexShrink: 0 }}>✗</span>{f}
          </div>
        ))}
      </div>
      <button onClick={onBtn} disabled={isActive} style={{ width: '100%', padding: 12, borderRadius: 10, fontFamily: 'Syne,sans-serif', fontSize: 11, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase', cursor: isActive ? 'default' : 'pointer', transition: 'all 0.2s ease', opacity: isActive ? 0.7 : 1, ...btnStyle }}>
        {btnLabel}
      </button>
      {note && <div style={{ textAlign: 'center', fontSize: 10, color: featured ? 'rgba(0,0,0,0.4)' : 'var(--dim)', marginTop: 8 }}>{note}</div>}
    </div>
  )
}

function FaqItem({ q, a }) {
  const [open, setOpen] = useState(false)
  return (
    <div style={{ borderBottom: '1px solid var(--border)', overflow: 'hidden' }}>
      <div onClick={() => setOpen(o => !o)} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 0', cursor: 'pointer', userSelect: 'none' }}>
        <span style={{ fontSize: 13, fontWeight: 600, paddingRight: 16 }}>{q}</span>
        <span style={{ color: 'var(--accent)', fontSize: 18, flexShrink: 0, transition: 'transform 0.3s ease', transform: open ? 'rotate(45deg)' : 'none' }}>+</span>
      </div>
      <div style={{ maxHeight: open ? 200 : 0, overflow: 'hidden', transition: 'max-height 0.4s ease' }}>
        <div style={{ paddingBottom: 14, fontSize: 13, color: 'var(--muted)', lineHeight: 1.7 }}>{a}</div>
      </div>
    </div>
  )
}

function PaymentModal({ plan, billing, price, onClose, onConfirm }) {
  const isPro = plan === 'pro'
  const label = isPro ? 'Pro ⚡' : 'Elite 💎'
  const accentCol = isPro ? 'var(--accent)' : 'var(--orange)'
  const period = billing === 'monthly' ? 'month' : 'year'
  const [copied, setCopied] = useState(false)
  const [confirmed, setConfirmed] = useState(false)

  const upiId = 'aadityarana@ybl' // PhonePe UPI from QR

  const copyUPI = () => {
    navigator.clipboard.writeText(upiId).then(() => { setCopied(true); setTimeout(() => setCopied(false), 2000) })
  }

  const handleConfirm = () => {
    setConfirmed(true)
    setTimeout(onConfirm, 1500)
  }

  return (
    <div onClick={e => e.target === e.currentTarget && onClose()} style={{ position: 'fixed', inset: 0, zIndex: 600, background: 'rgba(0,0,0,0.88)', backdropFilter: 'blur(12px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div style={{ background: 'var(--dark)', border: '1px solid var(--border2)', borderRadius: 24, padding: '40px 36px', maxWidth: 460, width: '100%', position: 'relative', animation: 'fadeUp 0.3s ease', maxHeight: '90vh', overflowY: 'auto' }}>
        <button onClick={onClose} style={{ position: 'absolute', top: 16, right: 16, width: 30, height: 30, borderRadius: '50%', background: 'var(--card2)', border: '1px solid var(--border2)', cursor: 'pointer', fontSize: 14, color: 'var(--muted)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>✕</button>

        {/* Badge */}
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '5px 12px', borderRadius: 100, fontSize: 10, letterSpacing: 2, textTransform: 'uppercase', fontWeight: 700, marginBottom: 20, background: isPro ? 'rgba(200,255,0,0.1)' : 'rgba(255,107,53,0.1)', color: accentCol, border: `1px solid ${accentCol}44` }}>
          {label} Plan
        </div>

        <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 26, fontWeight: 800, letterSpacing: -1, marginBottom: 6 }}>Pay & Activate</div>
        <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 28 }}>
          <strong style={{ color: accentCol, fontSize: 22, fontFamily: 'Syne,sans-serif' }}>₹{price.toLocaleString('en-IN')}</strong> / {period} · Cancel anytime
        </div>

        {/* Steps */}
        <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 12, padding: 20, marginBottom: 24 }}>
          <div style={{ fontSize: 10, letterSpacing: 2, textTransform: 'uppercase', color: 'var(--dim)', marginBottom: 14 }}>Payment Steps</div>

          {/* Step 1 — QR */}
          <div style={{ marginBottom: 20 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
              <div style={{ width: 24, height: 24, borderRadius: '50%', background: 'var(--accent)', color: '#000', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, flexShrink: 0 }}>1</div>
              <div style={{ fontSize: 14, fontWeight: 600 }}>QR Scan karo ya UPI ID use karo</div>
            </div>

            {/* PhonePe QR Image */}
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
              <div style={{ background: '#fff', padding: 12, borderRadius: 16, display: 'inline-block', boxShadow: '0 4px 20px rgba(200,255,0,0.1)' }}>
                <img src="/phonepe-qr.png" alt="PhonePe QR - Aaditya Rana" style={{ width: 180, height: 180, display: 'block', borderRadius: 8 }} />
              </div>
              <div style={{ fontSize: 12, color: 'var(--muted)', textAlign: 'center' }}>
                📱 GPay, PhonePe, Paytm, BHIM — koi bhi UPI app chalega
              </div>

              {/* UPI ID */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'var(--card2)', border: '1px solid var(--border2)', borderRadius: 10, padding: '10px 16px', width: '100%', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontSize: 10, color: 'var(--dim)', marginBottom: 2 }}>UPI ID</div>
                  <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 14, fontWeight: 700, color: 'var(--text)' }}>{upiId}</div>
                </div>
                <button onClick={copyUPI} style={{ background: copied ? 'var(--accent)' : 'var(--card)', color: copied ? '#000' : 'var(--muted)', border: '1px solid var(--border2)', borderRadius: 8, padding: '6px 14px', fontSize: 12, cursor: 'pointer', transition: 'all 0.2s ease', fontFamily: 'DM Sans,sans-serif', whiteSpace: 'nowrap' }}>
                  {copied ? '✓ Copied!' : 'Copy'}
                </button>
              </div>

              {/* Amount to pay */}
              <div style={{ background: isPro ? 'rgba(200,255,0,0.06)' : 'rgba(255,107,53,0.06)', border: `1px solid ${accentCol}33`, borderRadius: 10, padding: '10px 16px', width: '100%', textAlign: 'center' }}>
                <div style={{ fontSize: 11, color: 'var(--dim)', marginBottom: 2 }}>Exact Amount Bhejo</div>
                <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 22, fontWeight: 800, color: accentCol }}>₹{price.toLocaleString('en-IN')}</div>
                <div style={{ fontSize: 11, color: 'var(--muted)' }}>{label} Plan · {billing === 'yearly' ? 'Annual' : 'Monthly'}</div>
              </div>
            </div>
          </div>

          {/* Step 2 — Screenshot */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
              <div style={{ width: 24, height: 24, borderRadius: '50%', background: 'var(--card2)', border: '1px solid var(--border2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: 'var(--muted)', flexShrink: 0 }}>2</div>
              <div style={{ fontSize: 14, fontWeight: 600 }}>Payment screenshot WhatsApp pe bhejo</div>
            </div>
            <a href="https://wa.me/919399470011?text=FitAI%20Pro%20payment%20screenshot%20-%20" target="_blank" rel="noopener noreferrer" style={{ display: 'flex', alignItems: 'center', gap: 10, background: 'rgba(37,211,102,0.08)', border: '1px solid rgba(37,211,102,0.25)', borderRadius: 10, padding: '12px 16px', textDecoration: 'none', color: '#25d366', fontSize: 13, fontWeight: 600, transition: 'all 0.2s ease' }}
              onMouseEnter={e => e.currentTarget.style.background = 'rgba(37,211,102,0.15)'}
              onMouseLeave={e => e.currentTarget.style.background = 'rgba(37,211,102,0.08)'}>
              <span style={{ fontSize: 20 }}>💬</span>
              WhatsApp pe Screenshot Bhejo
            </a>
          </div>

          {/* Step 3 */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
              <div style={{ width: 24, height: 24, borderRadius: '50%', background: 'var(--card2)', border: '1px solid var(--border2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: 'var(--muted)', flexShrink: 0 }}>3</div>
              <div style={{ fontSize: 14, fontWeight: 600 }}>15 min mein plan activate ho jaayega</div>
            </div>
            <div style={{ fontSize: 12, color: 'var(--muted)', paddingLeft: 34 }}>Confirmation WhatsApp ya email pe aayega</div>
          </div>
        </div>

        {/* Confirm button */}
        <button onClick={handleConfirm} disabled={confirmed} style={{ width: '100%', padding: 15, background: confirmed ? 'var(--card2)' : isPro ? 'var(--accent)' : 'var(--orange)', color: confirmed ? 'var(--muted)' : '#000', border: 'none', borderRadius: 12, fontFamily: 'Syne,sans-serif', fontSize: 13, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase', cursor: confirmed ? 'not-allowed' : 'pointer', transition: 'all 0.25s ease', marginBottom: 10 }}>
          {confirmed ? '✓ Payment Confirmed...' : `Maine ₹${price.toLocaleString('en-IN')} Pay Kar Diya ✓`}
        </button>

        <div style={{ textAlign: 'center', fontSize: 11, color: 'var(--dim)' }}>
          🔒 Secure payment via PhonePe / UPI &nbsp;·&nbsp; Aaditya Rana
        </div>
      </div>
    </div>
  )
}

function SuccessModal({ plan, onClose }) {
  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 600, background: 'rgba(0,0,0,0.88)', backdropFilter: 'blur(12px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div style={{ background: 'var(--dark)', border: '1px solid var(--border2)', borderRadius: 24, padding: '48px 36px', maxWidth: 400, width: '100%', textAlign: 'center', animation: 'fadeUp 0.4s ease' }}>
        <div style={{ fontSize: 64, marginBottom: 16, animation: 'successPop 0.5s ease' }}>🎉</div>
        <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 26, fontWeight: 800, marginBottom: 8 }}>{plan} Activated!</div>
        <div style={{ fontSize: 14, color: 'var(--muted)', lineHeight: 1.7, marginBottom: 28 }}>
          Payment received! Confirmation bheja ja raha hai. 15 min mein sab features unlock ho jaayenge.
        </div>
        <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 12, padding: 16, marginBottom: 28, textAlign: 'left' }}>
          <div style={{ fontSize: 10, letterSpacing: 2, textTransform: 'uppercase', color: 'var(--dim)', marginBottom: 10 }}>Ab kya karo</div>
          {['Dashboard open karo', 'Aaj ka workout shuru karo', 'AI coach se baat karo'].map((s, i) => (
            <div key={i} style={{ display: 'flex', gap: 8, fontSize: 13, color: 'var(--muted)', marginBottom: 6 }}>
              <span style={{ color: 'var(--accent)' }}>→</span>{s}
            </div>
          ))}
        </div>
        <button className="btn-accent" onClick={onClose} style={{ width: '100%', padding: 14 }}>
          🏠 Dashboard Pe Jao
        </button>
      </div>
    </div>
  )
}
