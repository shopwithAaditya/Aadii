import { useState } from 'react'
import { generatePlan } from '../lib/ai'

const STEPS = 3

function ChoiceGrid({ options, selected, onSelect, cols = 2 }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: `repeat(${cols}, 1fr)`, gap: 10, marginBottom: 4 }}>
      {options.map(opt => (
        <button
          key={opt.value}
          onClick={() => onSelect(opt.value)}
          style={{
            padding: '13px 12px',
            background: selected === opt.value ? 'var(--accent-dim)' : 'var(--card)',
            border: `1px solid ${selected === opt.value ? 'var(--accent)' : 'var(--border2)'}`,
            borderRadius: 'var(--radius-sm)',
            color: selected === opt.value ? 'var(--accent)' : 'var(--muted)',
            fontFamily: 'DM Sans, sans-serif',
            fontSize: 13,
            cursor: 'pointer',
            transition: 'all 0.2s ease',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
            transform: selected === opt.value ? 'translateY(-2px)' : 'none',
            boxShadow: selected === opt.value ? '0 4px 16px rgba(200,255,0,0.12)' : 'none',
          }}
        >
          <span style={{ fontSize: 22 }}>{opt.emoji}</span>
          {opt.label}
        </button>
      ))}
    </div>
  )
}

export default function Onboarding({ onComplete, authName = '' }) {
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [loadStep, setLoadStep] = useState(0)
  const [form, setForm] = useState({
    name: '', age: '', height: '', weight: '', gender: '',
    goal: '', level: '', days: '', equip: '', diet: '', target: ''
  })

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }))

  const next = async () => {
    if (step === 1) {
      if (!form.name || !form.age || !form.height || !form.weight || !form.gender)
        return alert('Sabhi fields fill karo!')
    }
    if (step === 2) {
      if (!form.goal || !form.level || !form.days)
        return alert('Goal, level aur days select karo!')
    }
    if (step === 3) {
      if (!form.equip || !form.diet) return alert('Equipment aur diet select karo!')
      await generate()
      return
    }
    setStep(s => s + 1)
  }

  const generate = async () => {
    setLoading(true)
    const msgs = ['Body metrics analyze ho rahi hain...', 'Workout split design ho raha hai...', 'Indian diet plan ban raha hai...', 'Plan finalizing...']
    for (let i = 0; i < msgs.length; i++) {
      await delay(700 + i * 500)
      setLoadStep(i + 1)
    }
    try {
      const plan = await generatePlan(form)
      onComplete(form, plan)
    } catch {
      onComplete(form, fallback(form))
    }
  }

  const delay = ms => new Promise(r => setTimeout(r, ms))

  const fallback = (u) => {
    const cals = u.goal?.includes('Muscle') ? Math.round(u.weight * 32) : Math.round(u.weight * 26)
    return {
      summary: `${u.name} tera plan ready hai! ${u.goal} ke liye ${u.days} din train kar.`,
      calories: cals, protein: Math.round(u.weight * 2.2),
      carbs: Math.round(cals * 0.45 / 4), fat: Math.round(cals * 0.25 / 9),
      weeklySchedule: [
        { day: 'Monday', focus: 'Chest & Triceps', emoji: '💪', isRest: false, exercises: ['Bench Press 4x8-10', 'Incline Press 3x10', 'Cable Flyes 3x12', 'Tricep Pushdown 3x12', 'Overhead Extension 3x10'] },
        { day: 'Tuesday', focus: 'Back & Biceps', emoji: '🔙', isRest: false, exercises: ['Deadlift 4x6', 'Barbell Row 4x8', 'Lat Pulldown 3x12', 'Barbell Curl 3x10', 'Hammer Curl 3x12'] },
        { day: 'Wednesday', focus: 'Rest Day', emoji: '😴', isRest: true, exercises: [] },
        { day: 'Thursday', focus: 'Shoulders', emoji: '🏋️', isRest: false, exercises: ['OHP 4x8', 'Lateral Raises 4x15', 'Front Raises 3x12', 'Shrugs 4x12', 'Face Pulls 3x15'] },
        { day: 'Friday', focus: 'Legs', emoji: '🦵', isRest: false, exercises: ['Squats 4x8', 'RDL 3x10', 'Leg Press 3x12', 'Leg Curl 3x12', 'Calf Raises 4x20'] },
        { day: 'Saturday', focus: 'Arms & Core', emoji: '💥', isRest: false, exercises: ['EZ Curl 4x10', 'Preacher Curl 3x12', 'Dips 4x10', 'Skull Crushers 3x10', 'Plank 3x60s'] },
        { day: 'Sunday', focus: 'Rest Day', emoji: '🌿', isRest: true, exercises: [] },
      ],
      mealPlan: [
        { meal: 'Breakfast', emoji: '🌅', time: '7:00-8:00 AM', calories: Math.round(cals * 0.25), items: [{ name: 'Boiled Eggs', portion: '3 pcs', calories: 210, protein: 18 }, { name: 'Whole Wheat Roti', portion: '2 pcs', calories: 200, protein: 6 }, { name: 'Dahi', portion: '1 bowl', calories: 120, protein: 8 }] },
        { meal: 'Pre-Workout', emoji: '⚡', time: '11:00 AM', calories: Math.round(cals * 0.12), items: [{ name: 'Banana', portion: '2 pcs', calories: 180, protein: 2 }, { name: 'Peanut Butter', portion: '1 tbsp', calories: 90, protein: 4 }] },
        { meal: 'Lunch', emoji: '☀️', time: '1:00-2:00 PM', calories: Math.round(cals * 0.30), items: [{ name: 'Chicken / Dal', portion: '200g', calories: 300, protein: 40 }, { name: 'Rice', portion: '1.5 cup', calories: 300, protein: 6 }, { name: 'Sabzi', portion: '1 bowl', calories: 80, protein: 3 }] },
        { meal: 'Post-Workout', emoji: '💪', time: 'After Workout', calories: Math.round(cals * 0.10), items: [{ name: 'Whey / Doodh', portion: '1 scoop', calories: 150, protein: 25 }, { name: 'Banana', portion: '1 pc', calories: 90, protein: 1 }] },
        { meal: 'Dinner', emoji: '🌙', time: '7:00-8:00 PM', calories: Math.round(cals * 0.23), items: [{ name: 'Paneer / Chicken', portion: '150g', calories: 250, protein: 30 }, { name: 'Roti', portion: '2 pcs', calories: 200, protein: 6 }, { name: 'Dal', portion: '1 bowl', calories: 120, protein: 8 }] },
      ],
      tips: ['Workout ke baad 30 min mein protein lo', 'Roz 3-4 liter paani piyo', '7-8 ghante neend lo', 'Progressive overload follow karo', 'Consistency hi key hai'],
    }
  }

  if (loading) return <LoadingScreen step={loadStep} />

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}>
      {/* Ambient orb */}
      <div style={{ position: 'fixed', top: -100, right: -100, width: 400, height: 400, background: 'radial-gradient(circle, rgba(200,255,0,0.05), transparent)', borderRadius: '50%', pointerEvents: 'none' }} />

      <div style={{ maxWidth: 600, width: '100%', animation: 'fadeUp 0.5s ease both' }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: 40 }}>
          <div style={{ fontFamily: 'Syne, sans-serif', fontSize: 28, fontWeight: 800, marginBottom: 8 }}>
            Fit<span style={{ color: 'var(--accent)' }}>AI</span> Pro 🔥
          </div>
          <div style={{ fontSize: 14, color: 'var(--muted)', lineHeight: 1.6 }}>
            Tera AI personal trainer — Rs.10,000/month ka coach, Rs.299 mein
          </div>
        </div>

        {/* Progress dots */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 0, marginBottom: 36 }}>
          {[1, 2, 3].map((s, i) => (
            <div key={s} style={{ display: 'flex', alignItems: 'center', flex: 1 }}>
              <div style={{
                width: 28, height: 28, borderRadius: '50%', flexShrink: 0,
                background: step > s ? 'var(--accent)' : step === s ? 'var(--accent-dim)' : 'var(--card2)',
                border: `2px solid ${step >= s ? 'var(--accent)' : 'var(--border2)'}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 11, fontWeight: 700,
                color: step > s ? '#000' : step === s ? 'var(--accent)' : 'var(--dim)',
                transition: 'all 0.3s ease',
              }}>{step > s ? '✓' : s}</div>
              {i < 2 && <div style={{ flex: 1, height: 2, background: step > s ? 'var(--accent)' : 'var(--border2)', transition: 'background 0.4s ease' }} />}
            </div>
          ))}
        </div>

        {/* Card */}
        <div className="card" style={{ animation: 'fadeUp 0.4s ease both' }}>
          {step === 1 && <Step1 form={form} set={set} />}
          {step === 2 && <Step2 form={form} set={set} />}
          {step === 3 && <Step3 form={form} set={set} />}

          <div style={{ display: 'flex', gap: 12, marginTop: 28 }}>
            {step > 1 && (
              <button className="btn-outline" onClick={() => setStep(s => s - 1)} style={{ padding: '13px 24px' }}>
                ← Back
              </button>
            )}
            <button className="btn-accent" onClick={next} style={{ flex: 1 }}>
              {step === 3 ? '🚀 Generate My Plan' : 'Next →'}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

function Step1({ form, set }) {
  return (
    <>
      <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 20, fontWeight: 700, marginBottom: 4 }}>Basic Information 👤</div>
      <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 24 }}>Pehle apne baare mein batao</div>
      <div className="grid-2" style={{ marginBottom: 16 }}>
        <div><label className="form-label">Full Name</label><input className="form-input" placeholder="Tumhara naam" value={form.name} onChange={e => set('name', e.target.value)} /></div>
        <div><label className="form-label">Age</label><input className="form-input" type="number" placeholder="Umar" value={form.age} onChange={e => set('age', e.target.value)} /></div>
      </div>
      <div className="grid-2" style={{ marginBottom: 16 }}>
        <div><label className="form-label">Height (cm)</label><input className="form-input" type="number" placeholder="e.g. 175" value={form.height} onChange={e => set('height', e.target.value)} /></div>
        <div><label className="form-label">Weight (kg)</label><input className="form-input" type="number" placeholder="e.g. 72" value={form.weight} onChange={e => set('weight', e.target.value)} /></div>
      </div>
      <label className="form-label">Gender</label>
      <ChoiceGrid options={[{ value: 'Male', emoji: '♂️', label: 'Male' }, { value: 'Female', emoji: '♀️', label: 'Female' }]} selected={form.gender} onSelect={v => set('gender', v)} cols={2} />
    </>
  )
}

function Step2({ form, set }) {
  return (
    <>
      <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 20, fontWeight: 700, marginBottom: 4 }}>Goal & Experience 🎯</div>
      <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 24 }}>AI yahan se tera plan personalize karega</div>
      <label className="form-label">Main Goal</label>
      <ChoiceGrid cols={2} options={[{ value: 'Muscle Gain', emoji: '💪', label: 'Muscle Gain' }, { value: 'Fat Loss', emoji: '🔥', label: 'Fat Loss' }, { value: 'Toning', emoji: '⚡', label: 'Toning' }, { value: 'Strength', emoji: '🏋️', label: 'Strength' }]} selected={form.goal} onSelect={v => set('goal', v)} />
      <label className="form-label" style={{ marginTop: 16 }}>Fitness Level</label>
      <ChoiceGrid cols={3} options={[{ value: 'Beginner', emoji: '🌱', label: 'Beginner' }, { value: 'Intermediate', emoji: '⚡', label: 'Intermediate' }, { value: 'Advanced', emoji: '🔥', label: 'Advanced' }]} selected={form.level} onSelect={v => set('level', v)} />
      <label className="form-label" style={{ marginTop: 16 }}>Training Days / Week</label>
      <ChoiceGrid cols={4} options={[{ value: '3 days', emoji: '3️⃣', label: '3 Days' }, { value: '4 days', emoji: '4️⃣', label: '4 Days' }, { value: '5 days', emoji: '5️⃣', label: '5 Days' }, { value: '6 days', emoji: '6️⃣', label: '6 Days' }]} selected={form.days} onSelect={v => set('days', v)} />
    </>
  )
}

function Step3({ form, set }) {
  return (
    <>
      <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 20, fontWeight: 700, marginBottom: 4 }}>Equipment & Diet 🥗</div>
      <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 24 }}>Tere paas kya hai aur kya khata hai</div>
      <label className="form-label">Equipment</label>
      <ChoiceGrid cols={3} options={[{ value: 'No Equipment', emoji: '🏠', label: 'Home' }, { value: 'Basic Gym', emoji: '🏋️', label: 'Basic Gym' }, { value: 'Full Gym', emoji: '💪', label: 'Full Gym' }]} selected={form.equip} onSelect={v => set('equip', v)} />
      <label className="form-label" style={{ marginTop: 16 }}>Diet Type</label>
      <ChoiceGrid cols={2} options={[{ value: 'Vegetarian', emoji: '🥦', label: 'Vegetarian' }, { value: 'Non-Vegetarian', emoji: '🍗', label: 'Non-Veg' }, { value: 'Vegan', emoji: '🌱', label: 'Vegan' }, { value: 'No Preference', emoji: '🍽️', label: 'No Preference' }]} selected={form.diet} onSelect={v => set('diet', v)} />
      <div style={{ marginTop: 16 }}>
        <label className="form-label">Target Weight (kg) — Optional</label>
        <input className="form-input" type="number" placeholder="Tera goal weight" value={form.target} onChange={e => set('target', e.target.value)} />
      </div>
    </>
  )
}

const LOAD_MSGS = ['Body metrics analyze ho rahi hain...', 'Workout split design ho raha hai...', 'Indian diet plan ban raha hai...', 'Plan finalizing...']

function LoadingScreen({ step }) {
  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 32, padding: 24 }}>
      <div style={{ position: 'relative', width: 100, height: 100 }}>
        <div style={{ position: 'absolute', inset: 20, background: 'radial-gradient(circle, rgba(200,255,0,0.3), rgba(200,255,0,0.05))', borderRadius: '50%', animation: 'pulse 2s ease infinite' }} />
        {[0, 1, 2].map(i => (
          <div key={i} style={{ position: 'absolute', inset: i * 8, borderRadius: '50%', border: '2px solid transparent', borderTopColor: `rgba(200,255,0,${1 - i * 0.3})`, animation: `spin ${1.2 + i * 0.6}s linear infinite${i % 2 ? ' reverse' : ''}` }} />
        ))}
      </div>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 22, fontWeight: 700, marginBottom: 6 }}>AI Plan Bana Raha Hai 🤖</div>
        <div style={{ fontSize: 13, color: 'var(--muted)' }}>Teri details ke hisaab se personalized plan...</div>
      </div>
      <div style={{ width: '100%', maxWidth: 320 }}>
        {LOAD_MSGS.map((msg, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: '1px solid var(--border)', fontSize: 13, color: step > i ? 'var(--text)' : 'var(--dim)', transition: 'color 0.4s ease' }}>
            <div style={{ width: 22, height: 22, borderRadius: '50%', background: step > i ? 'var(--accent)' : 'var(--border2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, color: step > i ? '#000' : 'var(--dim)', transition: 'all 0.4s ease', flexShrink: 0 }}>
              {step > i ? '✓' : '⏳'}
            </div>
            {msg}
          </div>
        ))}
      </div>
    </div>
  )
}
