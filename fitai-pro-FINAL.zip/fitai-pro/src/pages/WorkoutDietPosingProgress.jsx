// ── WORKOUT PAGE ──
export function Workout({ state }) {
  const { plan, user } = state
  if (!plan) return null
  const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']
  const today = days[new Date().getDay()]

  return (
    <div style={{ animation: 'fadeUp 0.4s ease both' }}>
      <div style={{ marginBottom: 28 }}>
        <div style={{ fontSize: 10, letterSpacing: 3, textTransform: 'uppercase', color: 'var(--accent)', marginBottom: 8 }}>Training Program</div>
        <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 'clamp(24px,3vw,36px)', fontWeight: 800, letterSpacing: -1 }}>Workout <span style={{ color: 'var(--muted)' }}>Split</span></div>
        <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 6 }}>{user.goal} · {user.level} · {user.days} · {user.equip}</div>
      </div>

      {plan.tips?.length > 0 && (
        <div className="card" style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 10, letterSpacing: 2, textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 14 }}>AI Coach Tips</div>
          {plan.tips.map((tip, i) => (
            <div key={i} style={{ display: 'flex', gap: 10, fontSize: 13, color: 'var(--muted)', padding: '9px 0', borderBottom: i < plan.tips.length - 1 ? '1px solid var(--border)' : 'none' }}>
              <span style={{ color: 'var(--accent)', flexShrink: 0 }}>→</span>{tip}
            </div>
          ))}
        </div>
      )}

      {plan.weeklySchedule?.map((day, di) => {
        const isToday = day.day === today
        return (
          <div key={di} style={{ marginBottom: 28 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 10, letterSpacing: 2, textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 12, flexWrap: 'wrap' }}>
              {day.emoji} {day.day} — {day.focus}
              {isToday && <span style={{ background: 'var(--accent)', color: '#000', fontSize: 9, padding: '2px 8px', borderRadius: 100, letterSpacing: 1 }}>TODAY</span>}
            </div>
            {day.isRest ? (
              <div className="card" style={{ textAlign: 'center', padding: '24px', color: 'var(--muted)' }}>
                😴 Rest & Recovery<br /><span style={{ fontSize: 12 }}>Stretch, hydrate, sleep well</span>
              </div>
            ) : (
              day.exercises?.map((ex, i) => {
                const parts = ex.split(' ')
                const sets = parts[parts.length - 1]
                const name = parts.slice(0, -1).join(' ')
                return (
                  <div key={i} className="card" style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 8, padding: '16px 20px', transition: 'all 0.2s ease', cursor: 'default' }}
                    onMouseEnter={e => { e.currentTarget.style.transform = 'translateX(4px)'; e.currentTarget.style.borderColor = 'var(--accent-border)' }}
                    onMouseLeave={e => { e.currentTarget.style.transform = 'translateX(0)'; e.currentTarget.style.borderColor = 'var(--border)' }}>
                    <div style={{ width: 36, height: 36, background: 'var(--accent-dim)', border: '1px solid var(--accent-border)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Syne,sans-serif', fontSize: 12, fontWeight: 700, color: 'var(--accent)', flexShrink: 0 }}>
                      {String(i + 1).padStart(2, '0')}
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 3 }}>{name}</div>
                      <div style={{ fontSize: 12, color: 'var(--muted)' }}>Sets × Reps: {sets}</div>
                    </div>
                    <div style={{ background: 'var(--card2)', border: '1px solid var(--border2)', padding: '4px 10px', borderRadius: 100, fontSize: 10, color: 'var(--muted)' }}>
                      {day.focus.split(' ')[0]}
                    </div>
                  </div>
                )
              })
            )}
          </div>
        )
      })}
    </div>
  )
}

// ── DIET PAGE ──
export function Diet({ state }) {
  const { plan, user } = state
  if (!plan) return null
  const total = plan.protein * 4 + plan.carbs * 4 + plan.fat * 9
  const macros = [
    { label: 'Protein', val: `${plan.protein}g`, pct: Math.round(plan.protein * 4 / total * 100), color: 'var(--accent)' },
    { label: 'Carbs', val: `${plan.carbs}g`, pct: Math.round(plan.carbs * 4 / total * 100), color: 'var(--blue)' },
    { label: 'Fat', val: `${plan.fat}g`, pct: Math.round(plan.fat * 9 / total * 100), color: 'var(--orange)' },
  ]
  const R = 30, circ = 2 * Math.PI * R

  return (
    <div style={{ animation: 'fadeUp 0.4s ease both' }}>
      <div style={{ marginBottom: 28 }}>
        <div style={{ fontSize: 10, letterSpacing: 3, textTransform: 'uppercase', color: 'var(--accent)', marginBottom: 8 }}>Nutrition Plan</div>
        <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 'clamp(24px,3vw,36px)', fontWeight: 800, letterSpacing: -1 }}>Diet <span style={{ color: 'var(--muted)' }}>Plan</span></div>
        <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 6 }}>{user.diet} diet · {plan.calories} kcal/day · {user.goal}</div>
      </div>

      {/* Macro rings */}
      <div className="card" style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 10, letterSpacing: 2, textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 16 }}>Daily Macros</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 32, flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
            {macros.map((m, i) => (
              <div key={i} style={{ textAlign: 'center' }}>
                <svg width="80" height="80" viewBox="0 0 80 80" style={{ transform: 'rotate(-90deg)' }}>
                  <circle cx="40" cy="40" r={R} fill="none" stroke="var(--border2)" strokeWidth="5" />
                  <circle cx="40" cy="40" r={R} fill="none" stroke={m.color} strokeWidth="5" strokeLinecap="round"
                    strokeDasharray={circ} strokeDashoffset={circ - m.pct / 100 * circ}
                    style={{ transition: 'stroke-dashoffset 1.5s ease' }} />
                </svg>
                <div style={{ fontSize: 10, letterSpacing: 1, textTransform: 'uppercase', color: 'var(--muted)', marginTop: 4 }}>{m.label}</div>
                <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 13, fontWeight: 700 }}>{m.val}</div>
              </div>
            ))}
          </div>
          <div style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 2 }}>
            <div>🔥 <strong style={{ color: 'var(--text)' }}>{plan.calories} kcal</strong> — Daily Target</div>
            <div>🥩 <strong style={{ color: 'var(--text)' }}>{plan.protein}g</strong> — Protein</div>
            <div>🍚 <strong style={{ color: 'var(--text)' }}>{plan.carbs}g</strong> — Carbs</div>
            <div>🥑 <strong style={{ color: 'var(--text)' }}>{plan.fat}g</strong> — Fat</div>
          </div>
        </div>
      </div>

      {/* Meals */}
      {plan.mealPlan?.map((meal, mi) => {
        const totalCal = meal.items?.reduce((s, it) => s + it.calories, 0) || 0
        const totalPro = meal.items?.reduce((s, it) => s + it.protein, 0) || 0
        return (
          <div key={mi} className="card" style={{ marginBottom: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ fontSize: 22 }}>{meal.emoji}</span>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 15 }}>{meal.meal}</div>
                  <div style={{ fontSize: 11, color: 'var(--muted)' }}>⏰ {meal.time}</div>
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 18, fontWeight: 800, color: 'var(--accent)' }}>{totalCal}</div>
                <div style={{ fontSize: 10, color: 'var(--muted)' }}>kcal · {totalPro}g pro</div>
              </div>
            </div>
            {meal.items?.map((item, ii) => (
              <div key={ii} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '9px 0', borderTop: '1px solid var(--border)', fontSize: 13 }}>
                <div>
                  <div style={{ fontWeight: 500 }}>{item.name}</div>
                  <div style={{ fontSize: 11, color: 'var(--dim)' }}>{item.portion} · {item.protein}g protein</div>
                </div>
                <div style={{ fontWeight: 600, color: 'var(--muted)' }}>{item.calories} kcal</div>
              </div>
            ))}
          </div>
        )
      })}
    </div>
  )
}

// ── POSING PAGE ──
const POSES = [
  { e: '🏆', t: 'Front Double Bicep', d: 'Dono haath upar — bicep tight flex karo. Sabse classic pose.', tag: 'Must Learn' },
  { e: '💪', t: 'Side Chest', d: 'Side se body — chest push forward, arm press karo.', tag: 'Essential' },
  { e: '🔙', t: 'Back Double Bicep', d: 'Camera ko back dikhao. Lats spread, glutes tight.', tag: 'Back Power' },
  { e: '⚡', t: 'Vacuum Pose', d: 'Saas bahar, stomach andar — core strength dikhata hai.', tag: 'Advanced' },
  { e: '🎯', t: 'Most Muscular', d: 'Dono haath neeche — sabhi muscles ek saath max flex.', tag: 'Crowd Fav' },
  { e: '🌟', t: 'Side Tricep', d: 'Ek haath peeche — tricep hard flex, wrist down.', tag: 'Arms' },
  { e: '📐', t: 'Abs & Thigh', d: 'Haath sir ke peeche — abs squeeze, ek pairr side mein.', tag: 'Core' },
  { e: '🦅', t: 'Lat Spread', d: 'Haath kamar pe — lats bahar, V-shape dikhao.', tag: 'V-Shape' },
]

export function Posing() {
  return (
    <div style={{ animation: 'fadeUp 0.4s ease both' }}>
      <div style={{ marginBottom: 28 }}>
        <div style={{ fontSize: 10, letterSpacing: 3, textTransform: 'uppercase', color: 'var(--accent)', marginBottom: 8 }}>Posing Guide</div>
        <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 'clamp(24px,3vw,36px)', fontWeight: 800, letterSpacing: -1 }}>Master Your <span style={{ color: 'var(--muted)' }}>Poses</span></div>
        <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 6 }}>Roz 10 min practice karo — posing training ka hissa hai</div>
      </div>
      <div style={{ background: 'var(--accent-dim)', border: '1px solid var(--accent-border)', borderRadius: 12, padding: '13px 18px', display: 'flex', alignItems: 'center', gap: 12, fontSize: 13, marginBottom: 24 }}>
        <span style={{ fontSize: 18 }}>💡</span>
        Posing ek skill hai — training se utna hi important. Competition mein pose se 30% marks milte hain.
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 16 }}>
        {POSES.map((p, i) => (
          <div key={i} className="card" style={{ padding: 0, overflow: 'hidden', cursor: 'pointer', transition: 'all 0.25s ease', animation: `fadeUp 0.4s ${i * 0.05}s ease both` }}
            onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-6px)'; e.currentTarget.style.borderColor = 'var(--accent-border)'; e.currentTarget.style.boxShadow = '0 16px 40px rgba(0,0,0,0.3)' }}
            onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.boxShadow = 'none' }}>
            <div style={{ height: 130, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 60, background: 'var(--card2)', transition: 'background 0.2s ease' }}>
              {p.e}
            </div>
            <div style={{ padding: 14 }}>
              <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 4 }}>{p.t}</div>
              <div style={{ fontSize: 11, color: 'var(--muted)', lineHeight: 1.5, marginBottom: 10 }}>{p.d}</div>
              <span style={{ background: 'var(--accent-dim)', border: '1px solid var(--accent-border)', color: 'var(--accent)', fontSize: 9, letterSpacing: 1.5, textTransform: 'uppercase', padding: '3px 9px', borderRadius: 100 }}>{p.tag}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ── PROGRESS PAGE ──
export function Progress({ state, update }) {
  const { user, plan, streak = 1 } = state
  const stats = [
    { icon: '⚖️', label: 'Start Weight', value: `${user?.weight} kg`, sub: 'Day 1', glow: 'rgba(200,255,0,0.06)' },
    { icon: '🎯', label: 'Target', value: user?.target ? `${user.target} kg` : '—', sub: 'Goal weight', glow: 'rgba(0,212,255,0.04)' },
    { icon: '📅', label: 'Workouts', value: '0', sub: 'Done so far', glow: 'rgba(255,107,53,0.04)' },
    { icon: '🔥', label: 'Streak', value: streak, sub: 'Days active', glow: 'rgba(200,255,0,0.06)' },
  ]
  const badges = [
    { e: '🌱', n: 'Day 1', earned: true },
    { e: '🔥', n: '3 Day Streak', earned: streak >= 3 },
    { e: '⚡', n: 'First Week', earned: streak >= 7 },
    { e: '💪', n: '10 Workouts', earned: false },
    { e: '🏆', n: '30 Days', earned: streak >= 30 },
    { e: '💎', n: 'Transform', earned: false },
  ]

  return (
    <div style={{ animation: 'fadeUp 0.4s ease both' }}>
      <div style={{ marginBottom: 28 }}>
        <div style={{ fontSize: 10, letterSpacing: 3, textTransform: 'uppercase', color: 'var(--accent)', marginBottom: 8 }}>Progress</div>
        <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 'clamp(24px,3vw,36px)', fontWeight: 800, letterSpacing: -1 }}>Your <span style={{ color: 'var(--muted)' }}>Journey</span></div>
      </div>

      <div className="grid-4" style={{ marginBottom: 24 }}>
        {stats.map((s, i) => (
          <div key={i} className="card" style={{ position: 'relative', overflow: 'hidden' }}>
            <div style={{ position: 'absolute', top: -20, right: -20, width: 80, height: 80, background: `radial-gradient(circle, ${s.glow}, transparent)`, borderRadius: '50%' }} />
            <div style={{ fontSize: 22, marginBottom: 12 }}>{s.icon}</div>
            <div style={{ fontSize: 10, letterSpacing: 1.5, textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 4 }}>{s.label}</div>
            <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 'clamp(18px,2.5vw,26px)', fontWeight: 800, letterSpacing: -1, color: 'var(--accent)' }}>{s.value}</div>
            <div style={{ fontSize: 11, color: 'var(--dim)', marginTop: 3 }}>{s.sub}</div>
          </div>
        ))}
      </div>

      <div className="card" style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 10, letterSpacing: 2, textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 16 }}>Weight Log</div>
        <div style={{ textAlign: 'center', padding: '20px 0', color: 'var(--muted)', fontSize: 13 }}>
          📊 Roz weight log karo — progress graph mein dikhega
          <br />
          <button className="btn-accent" style={{ marginTop: 16, fontSize: 12, padding: '10px 20px' }}
            onClick={() => { const w = prompt('Aaj ka weight (kg):'); if (w && !isNaN(w)) alert(`✅ ${w} kg logged!`) }}>
            + Log Today's Weight
          </button>
        </div>
      </div>

      <div className="card">
        <div style={{ fontSize: 10, letterSpacing: 2, textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 16 }}>Achievement Badges</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 20 }}>
          {badges.map((b, i) => (
            <div key={i} style={{ textAlign: 'center', opacity: b.earned ? 1 : 0.3, transition: 'all 0.2s ease', cursor: 'default', width: 60 }}
              onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.1)'}
              onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}>
              <span style={{ fontSize: 34, display: 'block', marginBottom: 6 }}>{b.e}</span>
              <span style={{ fontSize: 10, color: 'var(--muted)', lineHeight: 1.3 }}>{b.n}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
