import { useState } from 'react'

export default function Auth({ onAuth }) {
  const [mode, setMode] = useState('login') // 'login' | 'signup'
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const set = (k, v) => { setForm(p => ({ ...p, [k]: v })); setError('') }

  const handleSubmit = async () => {
    setError('')

    // Basic validation
    if (!form.email || !form.password) return setError('Email aur password required hai')
    if (!form.email.includes('@')) return setError('Valid email daalo')
    if (form.password.length < 6) return setError('Password minimum 6 characters ka hona chahiye')

    if (mode === 'signup') {
      if (!form.name.trim()) return setError('Apna naam daalo')
      if (form.password !== form.confirm) return setError('Passwords match nahi kar rahe')

      // Check if already registered
      const existing = JSON.parse(localStorage.getItem('fitai_users') || '[]')
      if (existing.find(u => u.email === form.email)) return setError('Ye email already registered hai')

      setLoading(true)
      await delay(800)

      // Save user
      const newUser = { id: Date.now(), name: form.name, email: form.email, password: btoa(form.password), createdAt: new Date().toISOString() }
      localStorage.setItem('fitai_users', JSON.stringify([...existing, newUser]))
      localStorage.setItem('fitai_auth', JSON.stringify({ id: newUser.id, name: newUser.name, email: newUser.email }))
      setLoading(false)
      onAuth({ id: newUser.id, name: newUser.name, email: newUser.email }, true)

    } else {
      const existing = JSON.parse(localStorage.getItem('fitai_users') || '[]')
      const found = existing.find(u => u.email === form.email && u.password === btoa(form.password))
      if (!found) return setError('Email ya password galat hai')

      setLoading(true)
      await delay(600)
      localStorage.setItem('fitai_auth', JSON.stringify({ id: found.id, name: found.name, email: found.email }))
      setLoading(false)
      onAuth({ id: found.id, name: found.name, email: found.email }, false)
    }
  }

  const delay = ms => new Promise(r => setTimeout(r, ms))

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20, position: 'relative', overflow: 'hidden' }}>

      {/* Background orbs */}
      <div style={{ position: 'fixed', top: -100, right: -100, width: 500, height: 500, background: 'radial-gradient(circle, rgba(200,255,0,0.05), transparent)', borderRadius: '50%', pointerEvents: 'none' }} />
      <div style={{ position: 'fixed', bottom: -80, left: -80, width: 350, height: 350, background: 'radial-gradient(circle, rgba(0,212,255,0.04), transparent)', borderRadius: '50%', pointerEvents: 'none' }} />

      <div style={{ width: '100%', maxWidth: 440, animation: 'fadeUp 0.5s ease both' }}>

        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 40 }}>
          <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 32, fontWeight: 800, marginBottom: 8 }}>
            Fit<span style={{ color: 'var(--accent)' }}>AI</span> Pro
          </div>
          <div style={{ fontSize: 14, color: 'var(--muted)', lineHeight: 1.6 }}>
            {mode === 'signup' ? 'Account banao — free mein shuru karo 🚀' : 'Wapas aao — plan ready hai 💪'}
          </div>
        </div>

        {/* Card */}
        <div className="card" style={{ padding: '36px 32px' }}>

          {/* Tab switcher */}
          <div style={{ display: 'flex', background: 'var(--card2)', borderRadius: 10, padding: 4, marginBottom: 28, border: '1px solid var(--border)' }}>
            {['login', 'signup'].map(m => (
              <button key={m} onClick={() => { setMode(m); setError('') }} style={{ flex: 1, padding: '10px', borderRadius: 8, border: 'none', cursor: 'pointer', fontFamily: 'Syne,sans-serif', fontSize: 13, fontWeight: 700, letterSpacing: 0.5, transition: 'all 0.25s ease', background: mode === m ? 'var(--accent)' : 'transparent', color: mode === m ? '#000' : 'var(--muted)', textTransform: 'uppercase' }}>
                {m === 'login' ? 'Login' : 'Sign Up'}
              </button>
            ))}
          </div>

          {/* Form */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {mode === 'signup' && (
              <div>
                <label className="form-label">Full Name</label>
                <input className="form-input" type="text" placeholder="Tumhara naam" value={form.name} onChange={e => set('name', e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSubmit()} />
              </div>
            )}
            <div>
              <label className="form-label">Email Address</label>
              <input className="form-input" type="email" placeholder="email@example.com" value={form.email} onChange={e => set('email', e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSubmit()} />
            </div>
            <div>
              <label className="form-label">Password</label>
              <input className="form-input" type="password" placeholder="Min 6 characters" value={form.password} onChange={e => set('password', e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSubmit()} />
            </div>
            {mode === 'signup' && (
              <div>
                <label className="form-label">Confirm Password</label>
                <input className="form-input" type="password" placeholder="Password dobara daalo" value={form.confirm} onChange={e => set('confirm', e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSubmit()} />
              </div>
            )}
          </div>

          {/* Error */}
          {error && (
            <div style={{ background: 'rgba(255,68,68,0.08)', border: '1px solid rgba(255,68,68,0.25)', borderRadius: 10, padding: '10px 14px', marginTop: 16, fontSize: 13, color: '#ff6b6b', display: 'flex', alignItems: 'center', gap: 8 }}>
              ⚠️ {error}
            </div>
          )}

          {/* Submit */}
          <button
            className="btn-accent"
            onClick={handleSubmit}
            disabled={loading}
            style={{ width: '100%', marginTop: 24, padding: 15, fontSize: 14, opacity: loading ? 0.7 : 1, cursor: loading ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}
          >
            {loading ? (
              <>
                <div style={{ width: 16, height: 16, border: '2px solid #000', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
                {mode === 'signup' ? 'Account ban raha hai...' : 'Login ho raha hai...'}
              </>
            ) : (
              mode === 'signup' ? '🚀 Account Banao — Free' : '💪 Login Karo'
            )}
          </button>

          {/* Divider */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '20px 0' }}>
            <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
            <span style={{ fontSize: 11, color: 'var(--dim)', letterSpacing: 1 }}>OR</span>
            <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
          </div>

          {/* Switch mode */}
          <div style={{ textAlign: 'center', fontSize: 13, color: 'var(--muted)' }}>
            {mode === 'login' ? (
              <>Naya account chahiye? <button onClick={() => { setMode('signup'); setError('') }} style={{ background: 'none', border: 'none', color: 'var(--accent)', cursor: 'pointer', fontWeight: 700, fontSize: 13 }}>Sign Up karo →</button></>
            ) : (
              <>Pehle se account hai? <button onClick={() => { setMode('login'); setError('') }} style={{ background: 'none', border: 'none', color: 'var(--accent)', cursor: 'pointer', fontWeight: 700, fontSize: 13 }}>Login karo →</button></>
            )}
          </div>
        </div>

        {/* Trust line */}
        <div style={{ textAlign: 'center', marginTop: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 16, flexWrap: 'wrap' }}>
          {['🔒 Secure', '🆓 Free to start', '🇮🇳 Made in India'].map((t, i) => (
            <div key={i} style={{ fontSize: 11, color: 'var(--dim)' }}>{t}</div>
          ))}
        </div>
      </div>
    </div>
  )
}
