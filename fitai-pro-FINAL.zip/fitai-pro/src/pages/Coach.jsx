import { useState, useRef, useEffect } from 'react'
import { chatWithCoach } from '../lib/ai'

const SUGGESTIONS = [
  'Aaj ka workout kya hai?',
  'Muscle gain fast kaise hoga?',
  'Mera diet plan explain karo',
  'Protein shake lena chahiye?',
  'Chest bada kaise karoon?',
]

export default function Coach({ state }) {
  const { user, plan } = state
  const [msgs, setMsgs] = useState([
    { role: 'ai', text: `Tera AI Coach ready hai! 💪\n\nMujhe tera poora plan pata hai — goal, diet, workout sab. Kuch bhi pooch, seedha jawab dunga!` }
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [history, setHistory] = useState([])
  const bottomRef = useRef(null)

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs])

  const send = async (text) => {
    const msg = (text || input).trim()
    if (!msg || loading) return
    setInput('')
    setMsgs(m => [...m, { role: 'user', text: msg }])
    setLoading(true)

    const newHistory = [...history, { role: 'user', content: msg }]

    try {
      const reply = await chatWithCoach({ userProfile: user, plan, history: newHistory, message: msg })
      setMsgs(m => [...m, { role: 'ai', text: reply }])
      setHistory([...newHistory, { role: 'assistant', content: reply }])
    } catch {
      setMsgs(m => [...m, { role: 'ai', text: 'Network issue bhai! Dobara try karo 🔄' }])
    }
    setLoading(false)
  }

  return (
    <div style={{ animation: 'fadeUp 0.4s ease both', display: 'flex', flexDirection: 'column', height: 'calc(100vh - 160px)', minHeight: 400 }}>
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 10, letterSpacing: 3, textTransform: 'uppercase', color: 'var(--accent)', marginBottom: 8 }}>AI Personal Coach</div>
        <div style={{ fontFamily: 'Syne,sans-serif', fontSize: 'clamp(22px,3vw,32px)', fontWeight: 800, letterSpacing: -1 }}>Chat with <span style={{ color: 'var(--muted)' }}>Coach</span></div>
      </div>

      {/* Suggestions */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 16 }}>
        {SUGGESTIONS.map((s, i) => (
          <button key={i} onClick={() => send(s)} style={{ background: 'var(--card)', border: '1px solid var(--border2)', padding: '7px 14px', borderRadius: 100, fontSize: 12, color: 'var(--muted)', cursor: 'pointer', transition: 'all 0.2s ease' }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent)'; e.currentTarget.style.color = 'var(--accent)' }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border2)'; e.currentTarget.style.color = 'var(--muted)' }}>
            {s}
          </button>
        ))}
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 14, paddingRight: 4, scrollbarWidth: 'thin', scrollbarColor: 'var(--border2) transparent' }}>
        {msgs.map((m, i) => (
          <div key={i} style={{ display: 'flex', gap: 10, maxWidth: '88%', alignSelf: m.role === 'user' ? 'flex-end' : 'flex-start', flexDirection: m.role === 'user' ? 'row-reverse' : 'row', animation: 'fadeUp 0.3s ease' }}>
            <div style={{ width: 32, height: 32, borderRadius: '50%', background: m.role === 'ai' ? 'var(--accent-dim)' : 'var(--card2)', border: `1px solid ${m.role === 'ai' ? 'var(--accent-border)' : 'var(--border2)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, flexShrink: 0, alignSelf: 'flex-end' }}>
              {m.role === 'ai' ? '🤖' : '👤'}
            </div>
            <div style={{ padding: '12px 16px', borderRadius: 18, fontSize: 14, lineHeight: 1.65, background: m.role === 'user' ? 'var(--accent)' : 'var(--card)', border: m.role === 'ai' ? '1px solid var(--border)' : 'none', color: m.role === 'user' ? '#000' : 'var(--text)', borderBottomRightRadius: m.role === 'user' ? 4 : 18, borderBottomLeftRadius: m.role === 'ai' ? 4 : 18 }}>
              {m.text.split('\n').map((line, li) => <span key={li}>{line}{li < m.text.split('\n').length - 1 && <br />}</span>)}
            </div>
          </div>
        ))}
        {loading && (
          <div style={{ display: 'flex', gap: 10, alignSelf: 'flex-start', animation: 'fadeUp 0.3s ease' }}>
            <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--accent-dim)', border: '1px solid var(--accent-border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14 }}>🤖</div>
            <div style={{ padding: '14px 18px', borderRadius: '18px 18px 18px 4px', background: 'var(--card)', border: '1px solid var(--border)', display: 'flex', gap: 4 }}>
              {[0, 1, 2].map(d => <div key={d} style={{ width: 7, height: 7, background: 'var(--muted)', borderRadius: '50%', animation: `pulse 1.2s ${d * 0.2}s ease infinite` }} />)}
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div style={{ paddingTop: 16, borderTop: '1px solid var(--border)', display: 'flex', gap: 10, marginTop: 8 }}>
        <textarea
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }}
          placeholder="Apna sawaal likho..."
          rows={1}
          style={{ flex: 1, padding: '14px 18px', background: 'var(--card)', border: '1px solid var(--border2)', borderRadius: 'var(--radius-sm)', color: 'var(--text)', fontFamily: 'DM Sans,sans-serif', fontSize: 14, outline: 'none', resize: 'none', transition: 'border-color 0.2s ease' }}
          onFocus={e => e.target.style.borderColor = 'var(--accent)'}
          onBlur={e => e.target.style.borderColor = 'var(--border2)'}
        />
        <button onClick={() => send()} disabled={loading || !input.trim()} style={{ width: 50, height: 50, background: 'var(--accent)', border: 'none', borderRadius: 'var(--radius-sm)', cursor: loading ? 'not-allowed' : 'pointer', fontSize: 20, opacity: loading ? 0.5 : 1, transition: 'all 0.2s ease', flexShrink: 0 }}
          onMouseEnter={e => !loading && (e.currentTarget.style.transform = 'scale(1.05) rotate(-5deg)')}
          onMouseLeave={e => (e.currentTarget.style.transform = 'scale(1) rotate(0)')}>
          ➤
        </button>
      </div>
    </div>
  )
}
