import styles from './Sidebar.module.css'

const NAV = [
  { id:'dashboard',    icon:'🏠', label:'Dashboard' },
  { id:'workout',      icon:'💪', label:'Workout Plan' },
  { id:'diet',         icon:'🥗', label:'Diet Plan' },
  { id:'posing',       icon:'📸', label:'Posing Guide' },
  { id:'coach',        icon:'🤖', label:'AI Coach', badge:'AI' },
  { id:'progress',     icon:'📊', label:'Progress' },
  { id:'subscription', icon:'👑', label:'Subscription', badge:'PRO', badgeOrange:true },
]

export default function Sidebar({ page, navigate, state, update, open, auth, onLogout }) {
  const { activePlan='free', theme='dark' } = state
  const name = state.user?.name || auth?.name || 'User'
  const initial = name[0]?.toUpperCase() || '?'
  const planLabel = activePlan==='elite' ? 'Elite 💎' : activePlan==='pro' ? 'Pro ⚡' : 'Free'

  return (
    <nav className={`sidebar ${open ? 'open' : ''}`}>
      {/* Logo */}
      <div className={styles.logo}>
        <div className={styles.logoText}>Fit<span>AI</span> Pro</div>
        <div className={styles.logoSub}>AI Fitness Coach</div>
      </div>

      {/* Nav items */}
      <div className={styles.nav}>
        {NAV.map(item => (
          <button
            key={item.id}
            className={`${styles.navItem} ${page===item.id ? styles.active : ''}`}
            onClick={() => navigate(item.id)}
          >
            <span className={styles.navIcon}>{item.icon}</span>
            <span className={styles.navLabel}>{item.label}</span>
            {item.badge && (
              <span className={`${styles.badge} ${item.badgeOrange ? styles.badgeOrange : ''}`}>
                {item.badge}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Bottom controls */}
      <div className={styles.bottom}>
        {/* Theme toggle */}
        <button className={styles.themeToggle} onClick={() => update({ theme: theme==='dark' ? 'light' : 'dark' })}>
          <span style={{ fontSize:13, color:'var(--muted)' }}>{theme==='dark' ? '🌙 Dark Mode' : '☀️ Light Mode'}</span>
          <div className={`${styles.toggleSwitch} ${theme==='light' ? styles.toggleOn : ''}`}>
            <div className={styles.toggleKnob} />
          </div>
        </button>

        {/* User + logout */}
        <div className={styles.user}>
          <div className={styles.avatar}>{initial}</div>
          <div style={{ flex:1, minWidth:0 }}>
            <div className={styles.userName}>{name}</div>
            <div className={styles.userPlan}>{planLabel} Member</div>
          </div>
          <button
            onClick={onLogout}
            title="Logout"
            style={{ background:'var(--card)', border:'1px solid var(--border2)', borderRadius:8, width:30, height:30, cursor:'pointer', fontSize:14, color:'var(--muted)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, transition:'all 0.2s ease' }}
            onMouseEnter={e => { e.currentTarget.style.background='rgba(255,68,68,0.1)'; e.currentTarget.style.borderColor='rgba(255,68,68,0.3)'; e.currentTarget.style.color='#ff6b6b' }}
            onMouseLeave={e => { e.currentTarget.style.background='var(--card)'; e.currentTarget.style.borderColor='var(--border2)'; e.currentTarget.style.color='var(--muted)' }}
          >
            ⏻
          </button>
        </div>
      </div>
    </nav>
  )
}
