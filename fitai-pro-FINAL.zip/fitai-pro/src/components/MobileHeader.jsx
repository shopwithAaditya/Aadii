export function MobileHeader({ onMenu, theme, onTheme }) {
  return (
    <header className="mobile-header" style={{
      alignItems:'center', justifyContent:'space-between',
      padding:'14px 20px', background:'var(--dark)',
      borderBottom:'1px solid var(--border)',
      position:'sticky', top:0, zIndex:100,
      backdropFilter:'blur(20px)',
    }}>
      <button onClick={onMenu} style={{ width:36,height:36,background:'var(--card2)',border:'1px solid var(--border)',borderRadius:10,cursor:'pointer',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:5 }}>
        {[0,1,2].map(i=><span key={i} style={{width:18,height:2,background:'var(--text)',borderRadius:2,display:'block'}}/>)}
      </button>
      <div style={{fontFamily:'Syne,sans-serif',fontSize:18,fontWeight:800}}>
        Fit<span style={{color:'var(--accent)'}}>AI</span> Pro
      </div>
      <button onClick={onTheme} style={{width:36,height:36,background:'var(--card2)',border:'1px solid var(--border)',borderRadius:10,cursor:'pointer',fontSize:18}}>
        {theme==='dark'?'🌙':'☀️'}
      </button>
    </header>
  )
}

const MOB = [
  {id:'dashboard',icon:'🏠',label:'Home'},
  {id:'workout',  icon:'💪',label:'Train'},
  {id:'diet',     icon:'🥗',label:'Diet'},
  {id:'coach',    icon:'🤖',label:'Coach'},
  {id:'subscription',icon:'👑',label:'Plans'},
]

export function MobileNav({ page, navigate }) {
  return (
    <nav className="mobile-nav" style={{
      position:'fixed',bottom:0,left:0,right:0,
      background:'rgba(15,15,15,0.96)',backdropFilter:'blur(20px)',
      borderTop:'1px solid var(--border)',
      padding:'10px 8px 22px',zIndex:200,
      justifyContent:'space-around',alignItems:'center',
    }}>
      {MOB.map(item=>(
        <button key={item.id} onClick={()=>navigate(item.id)} style={{
          display:'flex',flexDirection:'column',alignItems:'center',gap:3,
          padding:'6px 10px',borderRadius:12,border:'none',cursor:'pointer',
          background:page===item.id?'var(--accent-dim)':'transparent',
          color:page===item.id?'var(--accent)':'var(--dim)',
          fontSize:10,fontFamily:'DM Sans,sans-serif',
          transition:'all 0.2s ease',minWidth:50,
        }}>
          <span style={{fontSize:20,transform:page===item.id?'scale(1.15)':'scale(1)',transition:'transform 0.2s ease'}}>
            {item.icon}
          </span>
          {item.label}
        </button>
      ))}
    </nav>
  )
}

export default MobileHeader
