import { useState, useEffect } from 'react'
import { getState, setState, getAuth, clearAuth } from './lib/store'
import Auth from './pages/Auth'
import Onboarding from './pages/Onboarding'
import Dashboard from './pages/Dashboard'
import { Workout, Diet, Posing, Progress } from './pages/WorkoutDietPosingProgress'
import Coach from './pages/Coach'
import Subscription from './pages/Subscription'
import Sidebar from './components/Sidebar'
import { MobileHeader, MobileNav } from './components/MobileHeader'

export default function App() {
  const [auth, setAuthState] = useState(() => getAuth())
  const [state, setAppState] = useState(() => getState())
  const [page, setPage] = useState('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const update = (partial) => {
    const next = setState(partial)
    setAppState({ ...next })
  }

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', state.theme || 'dark')
  }, [state.theme])

  const navigate = (p) => {
    setPage(p)
    setSidebarOpen(false)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const handleAuth = (authData, isNewUser) => {
    setAuthState(authData)
    // New user — clear old plan so onboarding shows
    if (isNewUser) update({ user: null, plan: null })
  }

  const handleLogout = () => {
    clearAuth()
    setAuthState(null)
    setAppState({ ...getState() })
    setPage('dashboard')
  }

  // 1. Not logged in → Auth screen
  if (!auth) return <Auth onAuth={handleAuth} />

  // 2. Logged in but no profile → Onboarding
  if (!state.user || !state.plan) {
    return (
      <Onboarding
        authName={auth.name}
        onComplete={(user, plan) => {
          update({ user: { ...user, name: user.name || auth.name }, plan })
          setPage('dashboard')
        }}
      />
    )
  }

  const props = { state, update, navigate }

  const pages = {
    dashboard:    <Dashboard    {...props} />,
    workout:      <Workout      {...props} />,
    diet:         <Diet         {...props} />,
    posing:       <Posing       {...props} />,
    coach:        <Coach        {...props} />,
    progress:     <Progress     {...props} />,
    subscription: <Subscription {...props} />,
  }

  return (
    <div className="app-shell">
      {sidebarOpen && (
        <div
          onClick={() => setSidebarOpen(false)}
          style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.7)', backdropFilter:'blur(4px)', zIndex:190 }}
        />
      )}

      <Sidebar
        page={page}
        navigate={navigate}
        state={state}
        update={update}
        open={sidebarOpen}
        auth={auth}
        onLogout={handleLogout}
      />

      <main className="main-content">
        <MobileHeader
          onMenu={() => setSidebarOpen(true)}
          theme={state.theme || 'dark'}
          onTheme={() => update({ theme: state.theme === 'dark' ? 'light' : 'dark' })}
        />
        <div style={{ padding: '28px 32px', paddingBottom: 100 }}>
          {pages[page] || pages.dashboard}
        </div>
      </main>

      <MobileNav page={page} navigate={navigate} />
    </div>
  )
}
